<?php

define("DBHOST", "localhost");
define("DBNAME", "mydb");
define("DBUSER", "root");
define("DBPASS", "");



?>