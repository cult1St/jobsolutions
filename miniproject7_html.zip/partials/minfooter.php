<footer class="container-fluid bg-light flex">
<div class="row justify-content-center"  id="contact" >
           <h3 class="text-center">Other ways to contact us</h3>
           <div class="col-md-4"  style="display: inline;">
            <a href="#"><img src="http://localhost/miniproject7_html/icons/facebook.png" alt="facebooklink" class="img-fluid" style="width: 30px;"></a>
            <a href="#"><img src="http://localhost/miniproject7_html/icons/instagram.png" alt="instagram link" class="img-fluid"  style="width: 30px;"></a>
            <a href="#"><img src="http://localhost/miniproject7_html/icons/whatsapp.png" alt="whatsapp link" class="img-fluid"  style="width: 30px;"></a>
           </div>
          
           <div class="col-12">
            <p class="text-center"> &copy;copyright <?php date("Y") ?> Job Solutions.All rights Reserved</p>
           </div>
           
           </div>
        </div>
    </div>
</footer>