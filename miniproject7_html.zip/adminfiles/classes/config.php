<?php

    error_reporting(E_ALL);

    define("DBHOST", "localhost");
    define("DBNAME", "mydb");
    define("DBUSER", "root");
    define("DBPASS", "");

?>